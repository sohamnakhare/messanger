F.merge('/js/default.js', '/js/jctajr.min.js', '/js/ui.js', '/js/default.js');
F.merge('/css/default.css', '/css/bootstrap.min.css', '/css/default.css', '/css/ui.css');