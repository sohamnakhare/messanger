F.global.users = EMPTYARRAY;
F.global.channels = EMPTYARRAY;