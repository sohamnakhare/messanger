F.global.merge = function(a, b) {
	return (a + b).split('').sort().join('');
};