F.localize('/templates/*.html', ['compress']);
F.localize('/forms/*.html', ['compress']);